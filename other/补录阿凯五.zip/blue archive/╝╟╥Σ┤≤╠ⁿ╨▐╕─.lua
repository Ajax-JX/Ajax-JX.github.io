if gg.getTargetInfo().x64==false or nil then
gg.alert("本脚本不适配当前系统框架哦~") os.exit() end
function GetAllResults()
   return gg.getResults(gg.getResultsCount())
end

function modeOfTable(t)
    local countTable = {}
    local maxCount = 0
    local modeValue = nil
    -- 计算每个元素出现的次数
    for _, v in ipairs(t) do
        if countTable[v] then
            countTable[v] = countTable[v] + 1
        else
            countTable[v] = 1
        end
        -- 更新出现次数最多的元素
        if countTable[v] > maxCount then
            maxCount = countTable[v]
            modeValue = v
        end
    end
    return {modeValue,maxCount}
end--返回的[1]是出现最多的值,[2]为最多的值出现的次数

function GetPointsTo(addr,isNumber)--获取指向
   Get=gg.getValues({{address=addr,flags=32}})[1]
   Hex=string.format("%x",Get.value)
   if isNumber==true then 
   return tonumber(Hex,16)--返回地址十进制
   end
   if not isNumber or isNumber==false then 
   return Hex
   end
end

function Class_LocatingClassName(Addr,MaxOffset)
local list={}
local str={}
   if not MaxOffset then MaxOffset=1000 end
   gg.clearResults()
   gg.setRanges(36)--A加Ca
   gg.loadResults({[1]={address=Addr,flags=32}})
   gg.searchPointer(MaxOffset)
   if gg.getResultsCount()==0 then print("没搜索到呢~") end
   for i,v in pairs(GetAllResults()) do
      addr=v.address
      Pointer=GetPointsTo(addr,true)--字段指针
      table.insert(list,Pointer)
   end
   Pointer=modeOfTable(list)[1]--确定字段指针
   ClassPointer=GetPointsTo(Pointer,true)--类名指针
   ClassStringPointer=ClassPointer+0x10--类名字符串指针
   StringHeader=GetPointsTo(ClassStringPointer,true)--类名字符串起始头
   --开始遍历类名
   py=-0x1
   for x=1,1024 do
      py=py+0x1
      Value=gg.getValues({{address=StringHeader+py,flags=1}})[1].value
      if Value==0 then break end
      if Value < 0 then break end
      if Value > 255 then break end
      string=string.char(Value)
      table.insert(str,string)
   end
   str=table.concat(str,"")
   gg.clearResults()
   return str
end--反查值的类名

function Class_Search(ClassName,FieldOffset,Type)
   gg.clearResults()
   gg.setRanges(-2080896)
   gg.searchNumber(":"..ClassName,1)
   first_letter=gg.getResults(1)[1].value
   gg.searchNumber(first_letter,1)
   local t={}
   for i,v in pairs(GetAllResults()) do
      gg.setRanges(-2080892)--Ca内存
      gg.loadResults({[1]={address=v.address,flags=1}})
      gg.searchPointer(0)
      if gg.getResultsCount()~=0 then table.insert(t,v.address) end
   end--取有结果的Byte
   ClassPointer={}
   for x,y in pairs(t) do
      gg.loadResults({[1]={address=y,flags=1}})
      gg.searchPointer(0)
      ClassStringPointer=GetAllResults()
      for a,b in pairs(ClassStringPointer) do
         if gg.getValues({{address=b.address-0x10,flags=4}})[1].value==0 then break end
         table.insert(ClassPointer,b.address-0x10)
      end
   end
   list={}
   for c,d in pairs(ClassPointer) do
      gg.setRanges(32)--设置A
      gg.loadResults({[1]={address=d,flags=32}})
      gg.searchPointer(0)
      gg.loadResults(GetAllResults())
      gg.searchPointer(0)
      for e,f in pairs(GetAllResults()) do
         f=f.value+FieldOffset--这个value就是指向的地址
         table.insert(list,f)
      end
   end
   gg.clearResults()
   return list
end--返回一个值的表

local gg = gg
local info = gg.getTargetInfo()
local off1, off2, ptrType = 0x8, 0x4, 4
if info.x64 then off1, off2, ptrType = 0x10, 0x8, 32 end
local metadata = {}

function tohex(val)
  return string.format('%x', val)
end

local function fastest()
    return gg.getRangesList("global-metadata.dat")
end

--Checking mscordlib in stringLiteral start
local function faster()
    local metadata = {}
    local allRanges = gg.getRangesList()
    local stringOffset = {} --0x18 of metadata, stringOffset
    local strStart = {}
    
    for i, v in ipairs(allRanges) do
        stringOffset[i] = {address=v.start+0x18, flags=gg.TYPE_DWORD}
    end
    stringOffset = gg.getValues(stringOffset)
    
    for i, v in ipairs(allRanges) do
        strStart[i] = {address=v.start+stringOffset[i].value, flags=gg.TYPE_DWORD}
    end
    strStart = gg.getValues(strStart)
    
    for i, v in ipairs(strStart) do
        --Every string table starts with mscorlib.dll in global-metadata.dat
        --So, if the first 4 bytes are "m(0x6D) s(0x73) c(0x63) o(0x6F)"
        if v.value==0x6F63736D then return {allRanges[i]} end
    end
    return {}
end

--Finding get_fieldOfView in Ca, A, O
local function fast()
    local searchMemoryRange = {
        gg.REGION_C_ALLOC,
        gg.REGION_ANONYMOUS,
        gg.REGION_OTHER,
        gg.REGION_C_HEAP,
    } --add regions where you want to search.
    
    --if you want to search all regions, use following value -1.
    --[[
    local searchMemoryRange = {
        -1,
    }
    --]]
    gg.clearResults()
    for i, v in ipairs(searchMemoryRange) do
        gg.setRanges(v)
        gg.searchNumber("h 00 67 65 74 5F 66 69 65 6C 64 4F 66 56 69 65 77 00", gg.TYPE_BYTE, false, gg.SIGH_EQUAL, 0, -1, 1)
        local res = gg.getResults(gg.getResultsCount())
        gg.clearResults()
        if #res>0 then
            for ii, vv in ipairs(gg.getRangesList()) do
                if res[1].address < vv["end"] and res[1].address > vv["start"] then
                    return {vv}
                end
            end
        end
    end
    return {}
end

local function get_metadata()
    local findingMethods = {
        [1] = fastest, --Getting metadata normally
        [2] = faster, --checking mscordlib in stringLiteral
        [3] = fast, --Finding get_fieldOfView in Ca, A, O
    }
    local metadata = {}
    
    for i=1, 3 do
        metadata = findingMethods[i]()
        if #metadata>0 then return metadata end
    end
    return {}
end

function isSameRegion(one, two)
  if not info.x64 then one=one&0xffffffff two=two&0xffffffff end
  local a=gg.getRangesList()
  for i, v in ipairs(a) do
    if one>=v.start and two<v['end'] then
      return true else return false
    end
  end
end

function getCorrectClassname(tab)
  local t={}
  local temp = {}
  for i, v in ipairs(tab) do
    temp[#temp+1], temp[#temp+2] = {address=v.address-1, flags=1}, {address=v.address+v.strLen, flags=1}
  end
  temp = gg.getValues(temp)
  for i=1, #temp, 2 do
    if temp[i].value==0 and temp[i+1].value==0 then table.insert(t, tab[(i+1)/2]) end
  end
  return t
end

function is_already_in_table(val, tab)
  for i, v in ipairs(tab) do
    if val==v.address then return true end
  end
  return false
end

function getField(Name,Offset,SJLX)
  gg.setVisible(false)
  local offForField = 0x8
  if info.x64 then offForField = 0x10 end 
  gg.clearResults()
  gg.setRanges(-2080896)
  gg.searchNumber(':'..Name, 4, false, gg.SIGH_EQUAL, metadata[1].start, metadata[1]['end'])
  local r = gg.getResults(gg.getResultsCount())
  gg.clearResults()
  if #r==0 then return gg.alert('Not found class name\n找不到类名') end
  
  local count = #r/#Name
  local t={}
  for i=1, count do
    local index = ((i-1)*#Name)+1
    r[index].strLen = #Name
    table.insert(t, r[index])
  end
  local a = getCorrectClassname(t)
  if #a==0 then return gg.alert('Not found class name\n找不到类名') end
  --check Ca addresses
  gg.setRanges(-2080892)
  gg.loadResults(a)
  gg.searchPointer(0)
  local r = gg.getResults(gg.getResultsCount())
  local t = {}
  for i, v in ipairs(r) do
    local a = {{address=v.address-off1, flags=1}, {address=v.address+off2, flags=ptrType}}
    a = gg.getValues(a)
    if not info.x64 then a[2].value=a[2].value&0xffffffff end
    if a[2].value>=metadata[1].start and a[2].value<metadata[1]['end'] then table.insert(t, a[1]) end
  end
  
  gg.setRanges(32)
  gg.loadResults(t)
  gg.searchPointer(0)
  gg.loadResults(gg.getResults(gg.getResultsCount()))
  gg.searchPointer(0)
  local r = gg.getResults(gg.getResultsCount())
  local t = {}
  for i, v in ipairs(r) do
    if not is_already_in_table(v.value, t) then table.insert(t, {address=v.value+Offset, flags=SJLX}) end
  end
  if #t==0 then return gg.alert('not found. may be this class is not allocated yet into memory.\n没有找到，可能这个类还没有分配到内存中。') end
  gg.loadResults(t)
  tableA={}
  resultA=gg.getResults(150)
  for p,l in pairs(resultA) do
     table.insert(tableA,l.address)
  end
  gg.clearResults()
 return tableA
end

local function LMss(LM,PY,SJLX)
  local a = gg.getFile()..'.cfg'
  local file = loadfile(a)
  local t = nil
  local pkg = info.packageName
  if not file then t={} else t=file() end
  
  ::here::
  local name_offset = t[pkg]
  if not name_offset then name_offset = {'PlayerScript', '0x4'} end
  
  local str = {}
  str[1]=LM
  str[2]=tostring(PY)
  if not str then return end
  if str[1]=='' then gg.alert('请输入类名！！') goto here end
  if str[2]=='' then gg.alert('请输入偏移量！！') goto here end
  
  if tostring(str[2])~='0' and tostring(str[2])~='0x0' and not tonumber(str[2]) then gg.alert('Error in offset. Put correct one.\n偏移量输入错误。请填写正确的。\nFor example,\n例如：\n\n0x1c --for hex offset\n50 --for decimal offset') goto here end
  str[2] = '0x'..tohex(str[2])
  t[pkg] = str
  str[2] = tonumber(tostring(str[2])) 
  local available = {}
  return getField(str[1], str[2], SJLX,XGNR)
end

metadata = get_metadata()
if not metadata then return gg.alert('找不到metadata') end
------------以上是配置，不懂勿动！

local function MR(Table,isget,flags,value)--Modify Return修改值用的
   local Re_table={}
   if isget==false then
      for i,v in pairs(Table) do
      local address=v['address']
      table.insert(Re_table,address)
      gg.setValues({{address=address,flags=flags,value=value}})
      gg.clearResults()
      end
   end
   if isget==true then
      for i,v in pairs(Table) do
      local address=v['address']
      table.insert(Re_table,address)
      print(address.."||"..string.format("0x%X",address))
      end
   end
   if isget~=false and true then
      for i,v in pairs(Table) do
      local address=v['address']
      table.insert(Re_table,address)
      end
   end
   return Re_table
end

gg.alert("请确保优香的记忆大厅已解锁")
if gg.getTargetInfo().packageName=="com.YostarJP.BlueArchive" then Class="MemoryLobbyDB" Offset=0x10 end--日服
if gg.getTargetInfo().packageName=="com.nexon.bluearchive" then Class="MemoryLobbyDB" Offset=0x10 end--国际服
list=LMss(Class,Offset,4)
addrList={}
idList={"修改未拥有角色"}
for i,v in pairs(list) do
   table.insert(addrList,{address=v,flags=4,value=gg.getValues({{address=v,flags=4}})[1].value})
   table.insert(idList,"地址:"..string.format("%X",v).." id:"..gg.getValues({{address=v,flags=4}})[1].value)
end
print(addrList)
p=gg.choice(idList,114514,"选择[以下id是你拥有回忆大厅的学生的id 修改你想要的学生id再选择值日生为她]")
for i,v in pairs(idList) do
   if p==i and p and i ~= 1 then
      a=gg.prompt({"修改的id"})
      gg.loadResults(addrList)
      gg.searchNumber(gg.getValues({{address=list[i-1],flags=4}})[1].value,4)
      gg.setValues({{address=gg.getResults(1)[1].address,flags=4,value=a[1]}})
      gg.clearResults()
   end
end
if p==1 then
   y=gg.prompt({"通过替换优香的id去添加未拥有角色\n输入你想要的学生id","恢复"},{},{"","checkbox"})
   if y[2]==false then
      if gg.getTargetInfo().packageName=="com.YostarJP.BlueArchive" then Array="Byte[]" end
      if gg.getTargetInfo().packageName=="com.nexon.bluearchive" then Array="Byte[]" end
      id=13010
      list=Class_Search(Array,0x20)
      t={}
      for i,v in pairs(list) do
        example={address=v,flags=4,value=gg.getValues({{address=v,flags=4}})[1].value}
        table.insert(t,example)
      end
      gg.loadResults(t)
      gg.searchNumber(id,4)
      print(gg.getResults(1)[1].address)
      gg.setValues({{address=gg.getResults(1)[1].address,value=y[1],flags=4}})
      gg.clearResults()
      gg.alert("现在去选择以下优香作为值日生就ok了 记得回来恢复")
   end
   if y[2]==true then
      o=gg.prompt({"你改为了谁的id"})
      if gg.getTargetInfo().packageName=="com.YostarJP.BlueArchive" then Array="Byte[]" end
      if gg.getTargetInfo().packageName=="com.nexon.bluearchive" then Array="Byte[]" end
      id=o[1]
      list=Class_Search(Array,0x20)
      t={}
      for i,v in pairs(list) do
        example={address=v,flags=4,value=gg.getValues({{address=v,flags=4}})[1].value}
        table.insert(t,example)
      end
      gg.loadResults(t)
      gg.searchNumber(id,4)
      gg.setValues({{address=gg.getResults(1)[1].address,value=13010,flags=4}})
      gg.clearResults()
   end
end
