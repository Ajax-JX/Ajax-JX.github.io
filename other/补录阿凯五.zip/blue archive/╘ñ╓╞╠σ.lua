function search(number, refine) -- number和refine各为一个表
    gg.clearResults()
    gg.setRanges(number[3])
    gg.searchNumber(number[1], number[2])
    if refine then
        if refine[2] == true then
            refine[2] = number[2]
        end
        if refine[3] == true then
            refine[3] = number[3]
        end
        gg.setRanges(refine[3])
        gg.searchNumber(refine[1], refine[2])
    end
    local a = gg.getResults(gg.getResultsCount())
    gg.clearResults()
    return a
end

local feature = "-240518168576;-56;4294967295;0::13"
local re = search({feature, 32, 8},{-56,32,8})
GH={}
for i,v in pairs(re) do
    pointer_value=tonumber(v.address+0x10)
    rt=search({pointer_value,4,32})
    for i,v in pairs(rt) do
       table.insert(GH,{address=v.address+0x40,flags=16})
    end
end
gg.loadResults(GH)
