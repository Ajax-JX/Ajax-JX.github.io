function GetAllResults()
   return gg.getResults(gg.getResultsCount())
end
function gv(addr,lx)
   return gg.getValues({{address=addr,flags=lx}})[1].value
end
function FeatureCode(main_table,Offset)--主表内嵌套其他副表
if not Offset then Offset=0 end
results={}
gg.clearResults()
   main_number=main_table[1][1]
   main_flags=main_table[1][2]
   main_ranges=main_table[1][3]
   gg.setRanges(main_ranges)
   gg.searchNumber(main_number,main_flags)
   for i,v in pairs(GetAllResults()) do
      v=v.address
      for x,y in pairs(main_table) do
         if x ~= 1 then
           Vice_value=y[1]
           Vice_flags=y[2]
           Vice_offset=y[3]
           if gv(v+Vice_offset,Vice_flags)==Vice_value then
              table.insert(results,v+Offset)
           end
         end
      end
   end
   gg.clearResults()
   return results
end--FeatureCode({{主,类型,内存范围},{副,类型,偏移}...(可写更多)...},主特征码与值的偏移)


A={
{982105859,4,32},
{1.0,16,-0xC}
}
B=FeatureCode(A)
if B[1] == nil then
   A={
    {977328183,4,32},
    {1.0,16,-0xC}
    }
   B=FeatureCode(A)
end

T=gg.alert("","开启","关闭")
for i,v in pairs(B) do
print(string.format("%X",v-0x90))
   if T==2 then--开
      gg.setValues({{address=v-0x90,flags=16,value=1}})
      gg.setValues({{address=v-0x94,flags=16,value=1}})
      gg.setValues({{address=v-0x98,flags=16,value=1}})
      gg.setValues({{address=v-0x9C,flags=16,value=1}})
   end
   if T==1 then--关
      gg.setValues({{address=v-0x90,flags=16,value=0}})
      gg.setValues({{address=v-0x94,flags=16,value=0}})
      gg.setValues({{address=v-0x98,flags=16,value=0}})
      gg.setValues({{address=v-0x9C,flags=16,value=0}})
   end
end
