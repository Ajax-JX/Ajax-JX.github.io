if gg.getTargetInfo().x64==false or nil then
gg.alert("本脚本不适配当前系统框架哦~") os.exit() end
function GetAllResults()
   return gg.getResults(gg.getResultsCount())
end

function modeOfTable(t)
    local countTable = {}
    local maxCount = 0
    local modeValue = nil
    -- 计算每个元素出现的次数
    for _, v in ipairs(t) do
        if countTable[v] then
            countTable[v] = countTable[v] + 1
        else
            countTable[v] = 1
        end
        -- 更新出现次数最多的元素
        if countTable[v] > maxCount then
            maxCount = countTable[v]
            modeValue = v
        end
    end
    return {modeValue,maxCount}
end--返回的[1]是出现最多的值,[2]为最多的值出现的次数

function GetPointsTo(addr,isNumber)--获取指向
   Get=gg.getValues({{address=addr,flags=32}})[1]
   Hex=string.format("%x",Get.value)
   if isNumber==true then 
   return tonumber(Hex,16)--返回地址十进制
   end
   if not isNumber or isNumber==false then 
   return Hex
   end
end

function Class_LocatingClassName(Addr,MaxOffset)
local list={}
local str={}
   if not MaxOffset then MaxOffset=1000 end
   gg.clearResults()
   gg.setRanges(36)--A加Ca
   gg.loadResults({[1]={address=Addr,flags=32}})
   gg.searchPointer(MaxOffset)
   if gg.getResultsCount()==0 then print("没搜索到呢~") end
   for i,v in pairs(GetAllResults()) do
      addr=v.address
      Pointer=GetPointsTo(addr,true)--字段指针
      table.insert(list,Pointer)
   end
   Pointer=modeOfTable(list)[1]--确定字段指针
   ClassPointer=GetPointsTo(Pointer,true)--类名指针
   ClassStringPointer=ClassPointer+0x10--类名字符串指针
   StringHeader=GetPointsTo(ClassStringPointer,true)--类名字符串起始头
   --开始遍历类名
   py=-0x1
   for x=1,1024 do
      py=py+0x1
      Value=gg.getValues({{address=StringHeader+py,flags=1}})[1].value
      if Value==0 then break end
      if Value < 0 then break end
      if Value > 255 then break end
      string=string.char(Value)
      table.insert(str,string)
   end
   str=table.concat(str,"")
   gg.clearResults()
   return str
end--反查值的类名

function Class_Search(ClassName,FieldOffset,Type)
   gg.clearResults()
   gg.setRanges(-2080896)
   gg.searchNumber(":"..ClassName,1)
   first_letter=gg.getResults(1)[1].value
   gg.searchNumber(first_letter,1)
   local t={}
   for i,v in pairs(GetAllResults()) do
      gg.setRanges(-2080892)--Ca内存
      gg.loadResults({[1]={address=v.address,flags=1}})
      gg.searchPointer(0)
      if gg.getResultsCount()~=0 then table.insert(t,v.address) end
   end--取有结果的Byte
   ClassPointer={}
   for x,y in pairs(t) do
      gg.loadResults({[1]={address=y,flags=1}})
      gg.searchPointer(0)
      ClassStringPointer=GetAllResults()
      for a,b in pairs(ClassStringPointer) do
         if gg.getValues({{address=b.address-0x10,flags=4}})[1].value==0 then break end
         table.insert(ClassPointer,b.address-0x10)
      end
   end
   list={}
   for c,d in pairs(ClassPointer) do
      gg.setRanges(32)--设置A
      gg.loadResults({[1]={address=d,flags=32}})
      gg.searchPointer(0)
      gg.loadResults(GetAllResults())
      gg.searchPointer(0)
      for e,f in pairs(GetAllResults()) do
         f=f.value+FieldOffset--这个value就是指向的地址
         table.insert(list,f)
      end
   end
   gg.clearResults()
   return list
end--返回一个值的表

if gg.getTargetInfo().packageName=="com.YostarJP.BlueArchive" then Array="Byte[]" end
if gg.getTargetInfo().packageName=="com.nexon.bluearchive" then Array="Byte[]" end
list=Class_Search(Array,0xb8)
t={}
for i,v in pairs(list) do
    example={address=v,flags=4,value=gg.getValues({{address=v,flags=4}})[1].value}
    table.insert(t,example)
end
gg.loadResults(t)