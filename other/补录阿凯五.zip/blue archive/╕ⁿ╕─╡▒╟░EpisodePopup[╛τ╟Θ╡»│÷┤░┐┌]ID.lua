if gg.getTargetInfo().x64==false or nil then
gg.alert("本脚本不适配当前系统框架哦~") os.exit() end
function GetAllResults()
   return gg.getResults(gg.getResultsCount())
end

function modeOfTable(t)
    local countTable = {}
    local maxCount = 0
    local modeValue = nil
    -- 计算每个元素出现的次数
    for _, v in ipairs(t) do
        if countTable[v] then
            countTable[v] = countTable[v] + 1
        else
            countTable[v] = 1
        end
        -- 更新出现次数最多的元素
        if countTable[v] > maxCount then
            maxCount = countTable[v]
            modeValue = v
        end
    end
    return {modeValue,maxCount}
end--返回的[1]是出现最多的值,[2]为最多的值出现的次数

function GetPointsTo(addr,isNumber)--获取指向
   Get=gg.getValues({{address=addr,flags=32}})[1]
   Hex=string.format("%x",Get.value)
   if isNumber==true then 
   return tonumber(Hex,16)--返回地址十进制
   end
   if not isNumber or isNumber==false then 
   return Hex
   end
end

local gg = gg
local info = gg.getTargetInfo()
local off1, off2, ptrType = 0x8, 0x4, 4
if info.x64 then off1, off2, ptrType = 0x10, 0x8, 32 end
local metadata = {}

function tohex(val)
  return string.format('%x', val)
end

local function fastest()
    return gg.getRangesList("global-metadata.dat")
end

--Checking mscordlib in stringLiteral start
local function faster()
    local metadata = {}
    local allRanges = gg.getRangesList()
    local stringOffset = {} --0x18 of metadata, stringOffset
    local strStart = {}
    
    for i, v in ipairs(allRanges) do
        stringOffset[i] = {address=v.start+0x18, flags=gg.TYPE_DWORD}
    end
    stringOffset = gg.getValues(stringOffset)
    
    for i, v in ipairs(allRanges) do
        strStart[i] = {address=v.start+stringOffset[i].value, flags=gg.TYPE_DWORD}
    end
    strStart = gg.getValues(strStart)
    
    for i, v in ipairs(strStart) do
        --Every string table starts with mscorlib.dll in global-metadata.dat
        --So, if the first 4 bytes are "m(0x6D) s(0x73) c(0x63) o(0x6F)"
        if v.value==0x6F63736D then return {allRanges[i]} end
    end
    return {}
end

--Finding get_fieldOfView in Ca, A, O
local function fast()
    local searchMemoryRange = {
        gg.REGION_C_ALLOC,
        gg.REGION_ANONYMOUS,
        gg.REGION_OTHER,
        gg.REGION_C_HEAP,
    } --add regions where you want to search.
    
    --if you want to search all regions, use following value -1.
    --[[
    local searchMemoryRange = {
        -1,
    }
    --]]
    gg.clearResults()
    for i, v in ipairs(searchMemoryRange) do
        gg.setRanges(v)
        gg.searchNumber("h 00 67 65 74 5F 66 69 65 6C 64 4F 66 56 69 65 77 00", gg.TYPE_BYTE, false, gg.SIGH_EQUAL, 0, -1, 1)
        local res = gg.getResults(gg.getResultsCount())
        gg.clearResults()
        if #res>0 then
            for ii, vv in ipairs(gg.getRangesList()) do
                if res[1].address < vv["end"] and res[1].address > vv["start"] then
                    return {vv}
                end
            end
        end
    end
    return {}
end

local function get_metadata()
    local findingMethods = {
        [1] = fastest, --Getting metadata normally
        [2] = faster, --checking mscordlib in stringLiteral
        [3] = fast, --Finding get_fieldOfView in Ca, A, O
    }
    local metadata = {}
    
    for i=1, 3 do
        metadata = findingMethods[i]()
        if #metadata>0 then return metadata end
    end
    return {}
end

function isSameRegion(one, two)
  if not info.x64 then one=one&0xffffffff two=two&0xffffffff end
  local a=gg.getRangesList()
  for i, v in ipairs(a) do
    if one>=v.start and two<v['end'] then
      return true else return false
    end
  end
end

function getCorrectClassname(tab)
  local t={}
  local temp = {}
  for i, v in ipairs(tab) do
    temp[#temp+1], temp[#temp+2] = {address=v.address-1, flags=1}, {address=v.address+v.strLen, flags=1}
  end
  temp = gg.getValues(temp)
  for i=1, #temp, 2 do
    if temp[i].value==0 and temp[i+1].value==0 then table.insert(t, tab[(i+1)/2]) end
  end
  return t
end

function is_already_in_table(val, tab)
  for i, v in ipairs(tab) do
    if val==v.address then return true end
  end
  return false
end

function getField(Name,Offset,SJLX)
  gg.setVisible(false)
  local offForField = 0x8
  if info.x64 then offForField = 0x10 end 
  gg.clearResults()
  gg.setRanges(-2080896)
  gg.searchNumber(':'..Name, 4, false, gg.SIGH_EQUAL, metadata[1].start, metadata[1]['end'])
  local r = gg.getResults(gg.getResultsCount())
  gg.clearResults()
  if #r==0 then return gg.alert('Not found class name\n找不到类名') end
  
  local count = #r/#Name
  local t={}
  for i=1, count do
    local index = ((i-1)*#Name)+1
    r[index].strLen = #Name
    table.insert(t, r[index])
  end
  local a = getCorrectClassname(t)
  if #a==0 then return gg.alert('Not found class name\n找不到类名') end
  --check Ca addresses
  gg.setRanges(-2080892)
  gg.loadResults(a)
  gg.searchPointer(0)
  local r = gg.getResults(gg.getResultsCount())
  local t = {}
  for i, v in ipairs(r) do
    local a = {{address=v.address-off1, flags=1}, {address=v.address+off2, flags=ptrType}}
    a = gg.getValues(a)
    if not info.x64 then a[2].value=a[2].value&0xffffffff end
    if a[2].value>=metadata[1].start and a[2].value<metadata[1]['end'] then table.insert(t, a[1]) end
  end
  
  gg.setRanges(32)
  gg.loadResults(t)
  gg.searchPointer(0)
  gg.loadResults(gg.getResults(gg.getResultsCount()))
  gg.searchPointer(0)
  local r = gg.getResults(gg.getResultsCount())
  local t = {}
  for i, v in ipairs(r) do
    if not is_already_in_table(v.value, t) then table.insert(t, {address=v.value+Offset, flags=SJLX}) end
  end
  if #t==0 then return gg.alert('not found. may be this class is not allocated yet into memory.\n没有找到，可能这个类还没有分配到内存中。') end
  gg.loadResults(t)
  tableA={}
  resultA=gg.getResults(150)
  for p,l in pairs(resultA) do
     table.insert(tableA,l.address)
  end
  gg.clearResults()
 return tableA
end

local function LMss(LM,PY,SJLX)
  local a = gg.getFile()..'.cfg'
  local file = loadfile(a)
  local t = nil
  local pkg = info.packageName
  if not file then t={} else t=file() end
  
  ::here::
  local name_offset = t[pkg]
  if not name_offset then name_offset = {'PlayerScript', '0x4'} end
  
  local str = {}
  str[1]=LM
  str[2]=tostring(PY)
  if not str then return end
  if str[1]=='' then gg.alert('请输入类名！！') goto here end
  if str[2]=='' then gg.alert('请输入偏移量！！') goto here end
  
  if tostring(str[2])~='0' and tostring(str[2])~='0x0' and not tonumber(str[2]) then gg.alert('Error in offset. Put correct one.\n偏移量输入错误。请填写正确的。\nFor example,\n例如：\n\n0x1c --for hex offset\n50 --for decimal offset') goto here end
  str[2] = '0x'..tohex(str[2])
  t[pkg] = str
  str[2] = tonumber(tostring(str[2])) 
  local available = {}
  return getField(str[1], str[2], SJLX,XGNR)
end

metadata = get_metadata()
if not metadata then return gg.alert('找不到metadata') end
------------以上是配置，不懂勿动！

local function MR(Table,isget,flags,value)--Modify Return修改值用的
   local Re_table={}
   if isget==false then
      for i,v in pairs(Table) do
      local address=v['address']
      table.insert(Re_table,address)
      gg.setValues({{address=address,flags=flags,value=value}})
      gg.clearResults()
      end
   end
   if isget==true then
      for i,v in pairs(Table) do
      local address=v['address']
      table.insert(Re_table,address)
      print(address.."||"..string.format("0x%X",address))
      end
   end
   if isget~=false and true then
      for i,v in pairs(Table) do
      local address=v['address']
      table.insert(Re_table,address)
      end
   end
   return Re_table
end

function  readL(filePath, rowNumber)
    local openFile = io.open(filePath, "r")
    assert(openFile, "read file is nil")
    local reTable = {}
    local reIndex = 0
    for r in openFile:lines() do
        reIndex = reIndex + 1
        reTable[reIndex] = r
    end
    if rowNumber then
    return reTable[rowNumber]
    else
    return reTable
    end
end

function Main()
if gg.getTargetInfo().packageName=="com.YostarJP.BlueArchive" then EpisodeClass="UIScenarioMode_EpisodePopup" EpiscodeOffset=0x150 end--日服
if gg.getTargetInfo().packageName=="com.nexon.bluearchive" then EpisodeClass="UIScenarioMode_EpisodePopup" EpiscodeOffset=0x128 end--国际服
--上为剧情慕类   下为章节类
if gg.getTargetInfo().packageName=="com.YostarJP.BlueArchive" then ChapterClass="UIScenarioMode_MainChapterList" ChapterOffset=0xa0 end--日服
if gg.getTargetInfo().packageName=="com.nexon.bluearchive" then ChapterClass="UIScenarioMode_MainChapterList" ChapterOffset=0x98 end--国际服
local read=io.open("/storage/emulated/0/Value.txt","r")
if read==nil then 
   io.open("/storage/emulated/0/Value.txt","w"):write(" \n \n"):close()
end
local read=io.open("/storage/emulated/0/Addr.txt","r")
if read==nil then 
   io.open("/storage/emulated/0/Addr.txt","w"):write(""):close()
end


if io.open("/storage/emulated/0/Addr.txt"):read("*a")=="" then 
      C=LMss(ChapterClass,ChapterOffset,4)
      E=LMss(EpisodeClass,EpiscodeOffset,4)
      c={}
      e={}
      for i,v in pairs(C) do
         if gg.getValues({{address=v,flags=4}})[1].value~=0 then table.insert(c,v) end
      end
      for i,v in pairs(E) do
         if gg.getValues({{address=v,flags=4}})[1].value~=0 then table.insert(e,v) end
      end
      io.open("/storage/emulated/0/Addr.txt","w"):write(c[1].."\n"..e[1]):close()
      
end
c1=gg.getValues({{address=readL("/storage/emulated/0/Addr.txt",1),flags=4}})[1].value
e1=gg.getValues({{address=readL("/storage/emulated/0/Addr.txt",2),flags=4}})[1].value
io.open("/storage/emulated/0/Value.txt","w"):write(c1.."\n"..e1):close()

   ChapterID=readL("/storage/emulated/0/Value.txt",1)
   EpisodeID=readL("/storage/emulated/0/Value.txt",2)
   menu=gg.choice({"刷新","当前卷ID:"..ChapterID,"当前剧慕ID:"..EpisodeID},2023,"BY九仙or玖仙\n如果值出现混乱请点击刷新\n点刷新前请随便点击一个卷 再点击随便一章中的剧慕点击入场等待弹出窗口")
   if menu==1 then
      os.remove("/storage/emulated/0/Addr.txt")
      C=LMss(ChapterClass,ChapterOffset,4)
      E=LMss(EpisodeClass,EpiscodeOffset,4)
      c={}
      e={}
      for i,v in pairs(C) do
         if gg.getValues({{address=v,flags=4}})[1].value~=0 then table.insert(c,v) end
      end
      for i,v in pairs(E) do
         if gg.getValues({{address=v,flags=4}})[1].value~=0 then table.insert(e,v) end
      end
      io.open("/storage/emulated/0/Addr.txt","w"):write(c[1].."\n"..e[1]):close()
      
   end
   
   if menu==2 then 
   ChapterAddr=readL("/storage/emulated/0/Addr.txt",1)
   ChapterValue=gg.getValues({{address=ChapterAddr,flags=4}})[1].value
   p=gg.prompt({"输入修改值\nvolume卷ID\n第一卷 1\n第二卷 2\n第三卷 3\n第四卷 4\n第五卷 5\n最终卷 100"},{ChapterValue})
      gg.setValues({{address=ChapterAddr,value=p[1],flags=4}})
   end
   if menu==3 then
   EpisodeAddr=readL("/storage/emulated/0/Addr.txt",2)
   EpisodeValue=gg.getValues({{address=EpisodeAddr,flags=4}})[1].value
   p=gg.prompt({"输入修改值\nEpisode剧目ID\n例如\n第一卷章节一第一幕 11010\n第一卷章节一第二幕 11020\n第二卷章节一第一幕 21010\n最终章(ID100)章节一第一幕 101010"},{EpisodeValue})
      gg.setValues({{address=EpisodeAddr,value=p[1],flags=4}})
   end

end

gg.showUiButton()
  while true do
    if gg.isClickedUiButton() then Main()end
  end