function gv(addr,jk)
   return gg.getValues({{address=addr,flags=jk}})[1].value
end

function getName(addr)--字符数量地址
    l={}
    for i=0,gv(addr,4) do
       table.insert(l,string.char(gv(addr+0x4+i*0x2,1)&0xFF)) 
    end
    return table.concat(l,'')
end

local h=gg.getResults(gg.getResultsCount())
for i,v in pairs(h) do
   print(getName(v.address-0x4))
end