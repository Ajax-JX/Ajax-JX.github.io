function ss(number)
   gg.clearResults()
   gg.setRanges(32)
   gg.searchNumber(";"..number,2)
   local a=gg.getResults(1)[1].value
   gg.searchNumber(a,2)
   local b=gg.getResults(gg.getResultsCount())
   gg.clearResults()
   return b
end

function str_debug_get(str)
   class_header={}
   for i,v in pairs(ss(str)) do
      pointer=v.address-0x14
      gg.searchNumber(tonumber(pointer),32)
      for x,y in pairs(gg.getResults(gg.getResultsCount())) do
          table.insert(class_header,y.address)
      end
   end
   gg.clearResults()
   return class_header
end

a=str_debug_get('EN0004')
for i,v in pairs(a) do
   gg.addListItems({{address=v,flags=4}})
end