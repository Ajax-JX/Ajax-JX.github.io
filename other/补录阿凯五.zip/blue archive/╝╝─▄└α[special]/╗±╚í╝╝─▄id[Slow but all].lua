local name="Hina"
--Q 'H' 00 'i' 00 'n' 00 'a' 00 'E' 00 'x' 00 '0' 00 '1' 00

function ex_ss(dev_name)--角色内部名称 并非正式名称
   dev_name=dev_name.."Ex01"
   local result = {}
   for i = 1, #dev_name do
        result[i] = "'"..dev_name:sub(i,i).."' "
   end
   return "Q "..table.concat(result,"00 ")
end

function public_ss(dev_name)--角色内部名称 并非正式名称
   dev_name=dev_name.."Public01"
   local result = {}
   for i = 1, #dev_name do
        result[i] = "'"..dev_name:sub(i,i).."' "
   end
   return "Q "..table.concat(result,"00 ")
end

function Passive_ss(dev_name)--角色内部名称 并非正式名称
   dev_name=dev_name.."Passive01"
   local result = {}
   for i = 1, #dev_name do
        result[i] = "'"..dev_name:sub(i,i).."' "
   end
   return "Q "..table.concat(result,"00 ")
end

function ExtraPassive_ss(dev_name)--角色内部名称 并非正式名称
   dev_name=dev_name.."ExtraPassive01"
   local result = {}
   for i = 1, #dev_name do
        result[i] = "'"..dev_name:sub(i,i).."' "
   end
   return "Q "..table.concat(result,"00 ")
end--ExtraPassive

function ss(number)
   gg.clearResults()
   gg.setRanges(32)
   gg.searchNumber(number)
   local a=gg.getResults(1)[1].value
   gg.searchNumber(a,1)
   local b=gg.getResults(gg.getResultsCount())
   gg.clearResults()
   return b
end

function ss_n(number,ty)
   gg.clearResults()
   gg.setRanges(32)
   gg.searchNumber(number,ty)
   local b=gg.getResults(gg.getResultsCount())
   gg.clearResults()
   return b
end

function gv(addr,jk)
   return gg.getValues({{address=addr,flags=jk}})[1].value
end


function removeDuplicates(tbl)
    local result = {}
    local hash = {}
    for _, v in ipairs(tbl) do
        if not hash[v] then
            result[#result + 1] = v
            hash[v] = true
        end
    end
    return result
end
results={}

tab_ex={}
for i,v in pairs(ss(ex_ss(name))) do
   local header=v.address-0x14
   local op=ss_n(tonumber(header),32)
   for x,y in pairs(op) do
      if op[1]~=nil and gv(y.address+0x10,4)~=0 then
         table.insert(tab_ex,y.address)
      end
   end
end
tab_pub={}
for i,v in pairs(ss(public_ss(name))) do
   local header=v.address-0x14
   local op=ss_n(tonumber(header),32)
   for x,y in pairs(op) do
      if op[1]~=nil and gv(y.address+0x10,4)~=0 then
         table.insert(tab_pub,y.address)
      end
   end
end
tab_pass={}
for i,v in pairs(ss(Passive_ss(name))) do
   local header=v.address-0x14
   local op=ss_n(tonumber(header),32)
   for x,y in pairs(op) do
      if op[1]~=nil and gv(y.address+0x10,4)~=0 then
         table.insert(tab_pass,y.address)
      end
   end
end
tab_expass={}
for i,v in pairs(ss(ExtraPassive_ss(name))) do
   local header=v.address-0x14
   local op=ss_n(tonumber(header),32)
   for x,y in pairs(op) do
      if op[1]~=nil and gv(y.address+0x10,4)~=0 then
         table.insert(tab_expass,y.address)
      end
   end
end
for i=1,#tab_ex+#tab_pub+#tab_pass+#tab_expass do
   table.insert(results,tab_ex[i]+0x10)
   table.insert(results,tab_pub[i]+0x10)
   table.insert(results,tab_pass[i]+0x10)
   table.insert(results,tab_expass[i]+0x10)
end
results=removeDuplicates(results)
for i,v in pairs(results) do
   gg.addListItems({{address=v,flags=4}})
end