

gg.clearResults()
gg.setRanges(32)
gg.searchNumber("Q '/data/app/~~xzX54i6-fqTTZUxNrUSzCQ==/com.YostarJP.BlueArchive-BqKgMVS6sVUpDzukQbAS7A==/lib/arm64/libxigncode.so' 00")
local h=gg.getResults(gg.getResultsCount())
gg.editAll("Q '/data/app/~~xzX54i6-fqTTZUxNrUSzCQ==/com.YostarJP.BlueArchive-BqKgMVS6sVUpDzukQbAS7A==/lib/arm64/libil2cpp.so' 00",1)
gg.clearResults()
