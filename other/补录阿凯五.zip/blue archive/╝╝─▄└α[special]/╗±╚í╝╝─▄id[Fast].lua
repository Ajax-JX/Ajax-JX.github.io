local name="EN0002"
--Q 'H' 00 'i' 00 'n' 00 'a' 00 'E' 00 'x' 00 '0' 00 '1' 00

function ex_ss(dev_name)--角色内部名称 并非正式名称
   dev_name=dev_name.."Ex01"
   local result = {}
   for i = 1, #dev_name do
        result[i] = "'"..dev_name:sub(i,i).."' "
   end
   return "Q "..table.concat(result,"00 ")
end

function public_ss(dev_name)--角色内部名称 并非正式名称
   dev_name=dev_name.."Public01"
   local result = {}
   for i = 1, #dev_name do
        result[i] = "'"..dev_name:sub(i,i).."' "
   end
   return "Q "..table.concat(result,"00 ")
end

function Passive_ss(dev_name)--角色内部名称 并非正式名称
   dev_name=dev_name.."Passive01"
   local result = {}
   for i = 1, #dev_name do
        result[i] = "'"..dev_name:sub(i,i).."' "
   end
   return "Q "..table.concat(result,"00 ")
end

function ExtraPassive_ss(dev_name)--角色内部名称 并非正式名称
   dev_name=dev_name.."ExtraPassive01"
   local result = {}
   for i = 1, #dev_name do
        result[i] = "'"..dev_name:sub(i,i).."' "
   end
   return "Q "..table.concat(result,"00 ")
end--ExtraPassive

function ss(number)
   gg.clearResults()
   gg.setRanges(32)
   gg.searchNumber(number)
   local a=gg.getResults(1)[1].value
   gg.searchNumber(a,1)
   local b=gg.getResults(gg.getResultsCount())
   gg.clearResults()
   return b
end

function ss_n(number,ty)
   gg.clearResults()
   gg.setRanges(32)
   gg.searchNumber(number,ty)
   local b=gg.getResults(gg.getResultsCount())
   gg.clearResults()
   return b
end

function gv(addr,jk)
   return gg.getValues({{address=addr,flags=jk}})[1].value
end

function getMinValue(tbl)
    if #tbl == 0 then
        error("表不能为空")
    end

    local minVal = tbl[1]
    for i = 2, #tbl do
        if tbl[i] < minVal then
            minVal = tbl[i]
        end
    end
    return minVal
end



tab_ex={}
for i,v in pairs(ss(ex_ss(name))) do
   local header=v.address-0x14
   local op=ss_n(tonumber(header),32)
   for x,y in pairs(op) do
      if op[1]~=nil and gv(y.address+0x10,4)~=0 and gv(y.address+0x10-0x4,4)==0 and gv(y.address+0x10-0x8,4)==1 and gv(y.address+0x10+0x4,4)==0 then
         table.insert(tab_ex,y.address+0x10)
      end
   end
end

table.sort(tab_ex)
print(tab_ex)
min=getMinValue(tab_ex)
tab_ex1={}
tab_ex1[1]=min
tab_ex1[2]=min+0x190
tab_ex1[3]=min+0x4b0
tab_ex1[4]=min+0x7d0
typen={
"EX",
"基础",
"被动",
"辅助"
}
for i,v in pairs(tab_ex1) do
   for x=1,10 do
       if x==1 then
          gg.addListItems({{address=v,flags=4,name=name.."的"..typen[i].."技能"..(x).."级"}})
       else
          gg.addListItems({{address=v+(0x28)*x,flags=4,name=name.."的"..typen[i].."技能"..(x).."级"}})
       end
   end
end