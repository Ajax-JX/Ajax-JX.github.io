local tmp_name="Yuuka"
function ex_ss(dev_name)--角色内部名称 并非正式名称
   dev_name=dev_name.."Ex01"
   local result = {}
   for i = 1, #dev_name do
        result[i] = "'"..dev_name:sub(i,i).."' "
   end
   return "Q "..table.concat(result,"00 ")
end

function ss(number)
   gg.clearResults()
   gg.setRanges(32)
   gg.searchNumber(number)
   local a=gg.getResults(1)[1].value
   gg.searchNumber(a,1)
   local b=gg.getResults(gg.getResultsCount())
   gg.clearResults()
   return b
end


function  read(filePath, rowNumber)
    local openFile = io.open(filePath, "r")
    assert(openFile, "read file is nil")
    local reTable = {}
    local reIndex = 0
    for r in openFile:lines() do
        reIndex = reIndex + 1
        reTable[reIndex] = r
    end
    if rowNumber then
    return reTable[rowNumber]
    else
    return reTable
    end
end

function gv(addr,jk)
   return gg.getValues({{address=addr,flags=jk}})[1].value
end

function getName(addr)--字符数量地址
    l={}
    for i=0,gv(addr,4) do
       table.insert(l,string.char(gv(addr+0x4+i*0x2,1)&0xFF)) 
    end
    return table.concat(l,'')
end

for i,v in pairs(ss(ex_ss(tmp_name))) do
   header=v.address-0x14
   if gv(header,4)~=0 then
      class_value=gv(header,4)
      break
   end
end

gg.sleep(2000)

if io.open("uu","r")~=nil then

else
   gg.alert("没找到\n请自行搜索获取头尾地址,数值:"..class_value)
   io.open("uu","w"):write("请替换为头地址\n请替换为尾地址"):close()
   gg.copyText(tostring(class_value))
   os.exit()
end
--objects={}
gg.sleep(2000)
gg.clearResults()
gg.setRanges(32)
gg.searchNumber(class_value, gg.TYPE_DWORD,false, gg.SIGN_EQUAL, tonumber(read("uu",1)), tonumber(read("uu",2)), 0)
gg.sleep(2000)
local h=gg.getResults(gg.getResultsCount())
gg.toast("当前剩余数值数量:"..gg.getResultsCount().."\n剩余组数:"..gg.getResultsCount()/6000)
if gg.getResultsCount() <=1000 then gg.alert("最后一步") os.exit() end
for i,v in pairs(h) do
   --table.insert(objects,{name=getName(v.address+0x14),uid=v.address})
   if i==6000 then os.remove("uu") io.open("uu","w"):write(v.address.."\n"..h[#h].address):close() break end
   io.open("解析结果511","a+"):write("{name="..getName(v.address+0x10)..",address="..v.address.."}".."\n"):close()
end
gg.clearResults()

