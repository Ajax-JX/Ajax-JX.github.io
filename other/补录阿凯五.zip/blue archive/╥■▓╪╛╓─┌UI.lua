function GetAllResults()
   return gg.getResults(gg.getResultsCount())
end
function gv(addr,lx)
   return gg.getValues({{address=addr,flags=lx}})[1].value
end
function getMaxValue(tbl)
    local max = tbl[1]
    for _, v in ipairs(tbl) do
        if v > max then
            max = v
        end
    end
    return max
end
function FeatureCode(main_table,Offset)--主表内嵌套其他副表
if not Offset then Offset=0 end
results={}
gg.clearResults()
   main_number=main_table[1][1]
   main_flags=main_table[1][2]
   main_ranges=main_table[1][3]
   gg.setRanges(main_ranges)
   gg.searchNumber(main_number,main_flags)
   for i,v in pairs(GetAllResults()) do
      v=v.address
      for x,y in pairs(main_table) do
         if x ~= 1 then
           Vice_value=y[1]
           Vice_flags=y[2]
           Vice_offset=y[3]
           if gv(v+Vice_offset,Vice_flags)==Vice_value then
              table.insert(results,v+Offset)
              break
           end
         end
      end
   end
   gg.clearResults()
   return results
end
function FeatureCodeGroup(main_table,Offset)--主表内嵌套其他副表
if not Offset then Offset=0 end
results={}
context={}
gg.clearResults()
   main_number=main_table[1][1]
   main_flags=main_table[1][2]
   main_ranges=main_table[1][3]
   gg.setRanges(main_ranges)
   for i,v in pairs(main_table) do
      Vice_value=v[1]
      Vice_flags=v[2]
      if Vice_flags==4 then Vice_flags="D" end
      if Vice_flags==127 then Vice_flags="A" end
      if Vice_flags==1 then Vice_flags="B" end
      if Vice_flags==64 then Vice_flags="E" end
      if Vice_flags==16 then Vice_flags="F" end
      if Vice_flags==32 then Vice_flags="Q" end
      if Vice_flags==2 then Vice_flags="W" end
      if Vice_flags==8 then Vice_flags="X" end
      table.insert(context,Vice_value..Vice_flags)
      if i ~= #main_table then
         table.insert(context,";")
      else
         table.insert(context,":")
      end
   end--列出搜索内容  
   local a={}
   for i,v in pairs(main_table) do
      Vice_offset=v[3]
      if Vice_offset <= 0 then Vice_offset=-Vice_offset end
      if i ~= 1 then
        table.insert(a,Vice_offset)
      end
   end
   max=getMaxValue(a)
   identifier=1+max
   table.insert(context,identifier)
   group=table.concat(context,"")
   
   gg.searchNumber(group)
   gg.searchNumber(main_table[1][1],main_table[1][2])
   for i,v in pairs(GetAllResults()) do
      v=v.address
      for x,y in pairs(main_table) do
         if x ~= 1 then
           Vice_value=y[1]
           Vice_flags=y[2]
           Vice_offset=y[3]
           if gv(v+Vice_offset,Vice_flags)==Vice_value then
              table.insert(results,v+Offset)
              break
           end
         end
      end
   end
   gg.clearResults()
   return results
end
function PreferentialSeach(main_table,Offset)
   gg.clearResults()
   gg.searchNumber(main_table[1][1],main_table[1][2])--搜索主特征码取结果数量
   if gg.getResultsCount() < 500 then
      return FeatureCode(main_table,Offset)
   else
      return FeatureCodeGroup(main_table,Offset)
   end
end


A={
{982105859,4,32},
{1065353216,4,-0xC}
}
B=FeatureCode(A,0x40)
if B[1]~=nil then
   gg.addListItems({{address=B[1]-0xC8,flags=16,name="改0"}})
else
   A={
    {977328183,4,32},
    {1065353216,4,-0xC}
    }
   B=FeatureCode(A,0x40)
   gg.addListItems({{address=B[1]-0xC8,flags=16,name="改0"}})
end