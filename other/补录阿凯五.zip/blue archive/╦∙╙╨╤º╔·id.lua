function gv(addr,jk)
   return gg.getValues({{address=addr,flags=jk}})[1].value
end

gg.clearResults()
gg.setRanges(32)
gg.searchNumber("10,004;10,004;13,010;13,010:33",4)
local h=gg.getResults(1)[1].address
py=0x18
for i=1,300 do
   if gv(h+i*py,4)~=0 then
      print(gv(h+i*py,4))
   end
end
gg.clearResults()