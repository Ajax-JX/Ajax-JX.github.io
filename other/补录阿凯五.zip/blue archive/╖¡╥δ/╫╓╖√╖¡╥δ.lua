function set(addr, flag, valu)
   gg.setValues({{address=addr, flags=flag, value=valu}})
end

function get(addr, flag)
  return gg.getValues({{address=addr, flags=flag}})[1].value
end

function utf16_to_utf8(utf16_code)
    -- 将负数转换为无符号整数
    if utf16_code < 0 then
        utf16_code=utf16_code + 0x10000
    end
    -- 检查输入是否在 UTF-16 的有效范围内
    if utf16_code > 0xFFFF then
        error("UTF-16 code point out of range (0x0000 to 0xFFFF)")
    end
    -- UTF-16 转 UTF-8 的逻辑
    if utf16_code <= 0x7F then
        -- 1 字节 UTF-8
        return string.char(utf16_code)
    elseif utf16_code <= 0x7FF then
        -- 2 字节 UTF-8
        local byte1=0xC0 | (utf16_code >> 6)
        local byte2=0x80 | (utf16_code & 0x3F)
        return string.char(byte1, byte2)
    else
        -- 3 字节 UTF-8
        local byte1=0xE0 | (utf16_code >> 12)
        local byte2=0x80 | ((utf16_code >> 6) & 0x3F)
        local byte3=0x80 | (utf16_code & 0x3F)
        return string.char(byte1, byte2, byte3)
    end
end

function containsJapanese(text)
    -- 定义日文字符范围
    local hiragana="[\u{3040}-\u{309F}]"
    local katakana="[\u{30A0}-\u{30FF}]"
    local kanji="[\u{4E00}-\u{9FFF}]"
    if string.find(text, hiragana) or string.find(text, katakana) or string.find(text, kanji) then
        return true
    else
        return false
    end
end

function getName(addr) -- 字符头地址
    function gv(addr, jk)
        return gg.getValues({{address=addr, flags=jk}})[1].value
    end
    t={}
    l={}
    count=gv(addr + 0x10, 4)
    for i=1, count do
        ar=(addr + 0x10 + 0x2) + i * 0x2
        table.insert(l,{address=ar,flags=2})
        table.insert(t, utf16_to_utf8(gv(ar, 2)))
    end
    return table.concat(t, ''),l
end

zz=function(Pointer, ranges)
    gg.setRanges(ranges)
    results=gg.getResults(gg.getResultsCount())
    gg.loadResults(results)
    gg.searchPointer(Pointer)
end

Vclass=function(leiming, offset)
    gg.clearResults()
    gg.setRanges(-2080892)
    gg.searchNumber(':' .. leiming, 1, false)
    local results=gg.getResults(gg.getResultsCount())
    for k, v in ipairs(results) do
        pp=string.sub(';' .. leiming, 1, 1)
        if v.value == pp then
            hqz={{address=v.address - 1, flags=1}}
            qb=gg.getValues(hqz)[1].value
            bl={{address=v.address + #leiming, flags=1}}
            bl2=gg.getValues(bl)[1].value
            if qb == 0 and bl2 == 0 then
                jzz={{address=v.address, flags=1}}
                gg.loadResults(jzz)
            end
        end
    end
    zz(0, -2080892)
    local result=gg.getResults(gg.getResultsCount())
    for key, value in ipairs(result) do
        value.address=value.address - 16
    end
    gg.loadResults(result)
    zz(0, 32)
    zz(0, 32)
    local get=gg.getResults(gg.getResultsCount())
    for abc, def in ipairs(get) do
        def.address=def.value
    end
    result={}
    if offset then
        gg.loadResults(get)
        get=gg.getResults(gg.getResultsCount())
        gg.clearResults()
        for x, y in pairs(get) do
            table.insert(result, {address=y.address + offset, flags=4})
        end
    else
        print("Fill in the parameters")
    end
    gg.clearResults()
    return result
end

function getR(input)
    -- 打开文件
    local file = io.open("对照.txt", "r")
    if not file then
        print("文件打开失败，请检查文件是否存在！")
        return nil
    end
    local lines = {}
    for line in file:lines() do
        table.insert(lines, line)
    end
    file:close()
    for _, line in ipairs(lines) do
        local key, value = string.match(line, "([^:]+):(.+)")
        if key and value then
            key = string.trim(key)
            value = string.trim(value)
            if key == input then
                return value
            end
        end
    end
    return nil
end

function string.trim(s)
    return s:match("^%s*(.-)%s*$")
end


function translation_JP2CN(text)
    url="https://translate.appworlds.cn?text=" .. text .. "&from=ja&to=zh-CN"
    lw1=gg.makeRequest(url).content
    return string.match(lw1, '"data":"(.-)",')
end

b=Vclass("UILabel", 0x258)
a=Vclass("EchelonPresetDB", 0x18)
for i, v in pairs(a) do
    p=get(v.address,32)
    str=getName(p)
    gg.clearResults()
    gg.setRanges(32)
    gg.searchNumber(";"..str,2)
    gg.getResults(gg.getResultsCount())
    if gg.getResultsCount()~=0 and getR(str) ~=nil then
       gg.editAll(";"..getR(str),2)
    end
end
k={}
for i,v in pairs(b) do
   if get(get(v.address,32),4)~=0 then
      str=getName(get(v.address,32))
      gg.clearResults()
      gg.sleep(800)
      gg.setRanges(32)
      gg.searchNumber(";"..str,2)
      gg.getResults(gg.getResultsCount())
      if gg.getResultsCount()~=0 and getR(str) ~=nil then
         gg.editAll(";"..getR(str),2)
      end
      table.insert(k,v) 
   end
end