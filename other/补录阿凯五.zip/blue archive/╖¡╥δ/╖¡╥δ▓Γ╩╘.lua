function set(addr,flag,valu)
   gg.setValues({{address=addr,flags=flag,value=valu}})
end
function get(addr,flag)
  return  gg.getValues({{address=addr,flags=flag}})[1].value
end
function utf16_to_utf8(utf16_code)
    -- UTF-16 转 UTF-8 的逻辑
    if utf16_code <= 0x7F then
        -- 1 字节 UTF-8
        return string.char(utf16_code)
    elseif utf16_code <= 0x7FF then
        -- 2 字节 UTF-8
        local byte1 = 0xC0 | (utf16_code >> 6)
        local byte2 = 0x80 | (utf16_code & 0x3F)
        return string.char(byte1, byte2)
    elseif utf16_code <= 0xFFFF then
        -- 3 字节 UTF-8
        local byte1 = 0xE0 | (utf16_code >> 12)
        local byte2 = 0x80 | ((utf16_code >> 6) & 0x3F)
        local byte3 = 0x80 | (utf16_code & 0x3F)
        return string.char(byte1, byte2, byte3)
    else
        error("UTF-16 code point out of range")
    end
end
function containsJapanese(text)
    -- 定义日文字符范围
    local hiragana = "[\u{3040}-\u{309F}]"
    local katakana = "[\u{30A0}-\u{30FF}]"
    local kanji = "[\u{4E00}-\u{9FFF}]"
    if string.find(text, hiragana) or string.find(text, katakana) or string.find(text, kanji) then
        return true
    else
        return false
    end
end
function first()
   gg.clearResults()
   gg.setRanges(32)
   gg.searchNumber(";生徒")
   local f=gg.getResults(1)[1].value
   gg.searchNumber(f,2)
   f=gg.getResults(gg.getResultsCount())
   gg.clearResults()
   for i,v in pairs(f) do
      if get(v.address-0x14,4)~=0 and get(v.address-0x4,4)==2 then
         return get(v.address-0x14,4)
      end
   end
end

gg.searchNumber(first(),4)
f=gg.getResults(gg.getResultsCount())
gg.clearResults()
for i,v in pairs(f) do
   string_count_address=v.address+0x10
   string_count=get(string_count_address,4)
   string_address=string_count_address+0x2
   t={}
   for x=1,string_count do
       value=get(string_address+x*0x2,2)
       string_JP=utf16_to_utf8(value)
       table.insert(t,string_JP)
   end
   string=table.concat(t,"")
   if containsJapanese(string)==true then
      print(string)
   end
end