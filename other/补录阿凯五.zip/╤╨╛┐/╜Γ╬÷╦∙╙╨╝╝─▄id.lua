require'特征码搜索'
function getName(addr)--字符数量地址
    function gv(addr,jk)
     return gg.getValues({{address=addr,flags=jk}})[1].value
    end
    l={}
    for i=0,gv(addr,4) do
       table.insert(l,string.char(gv(addr+0x4+i*0x2,1)&0xFF)) 
    end
    return table.concat(l,'')
end

gg.clearResults()
gg.setRanges(32)
gg.searchNumber("Q 'Y' 00 'u' 00 'u' 00 'k' 00 'a' 00 'E' 00 'x' 00 '0'")
gg.searchNumber(gg.getResults(1)[1].value,1)
t={}
for i,v in pairs(gg.getResults(gg.getResultsCount())) do
   t[i]={address=v.address-0x14,flags=4}
end
gg.loadResults(t)
gg.searchPointer(0)
k={}
for i,v in pairs(gg.getResults(gg.getResultsCount())) do
   if gg.getValues({{address=v.address-0x10+0x28,flags=4}})[1].value==gg.getValues({{address=v.address-0x10,flags=4}})[1].value and gg.getValues({{address=v.address-0x10+0x18,flags=4}})[1].value==1 then
      table.insert(k,{address=v.address-0x10,value=gg.getValues({{address=v.address-0x10,flags=4}})[1].value})
   end
end
gg.clearResults()
--↑为获取组头

A={
{k[1].value,4,32},
{-1,4,0xc},
{1,4,0x18}
}
all_skills=FeatureCodeGroup(A)
gg.clearResults()
h={}
for x,y in pairs(all_skills) do
   id=gg.getValues({{address=y+0x20,flags=4}})[1].value
   name=getName(gg.getValues({{address=y+0x10,flags=32}})[1].value+0x10)
   string='ID:'..id..'  Name:'..name
   table.insert(h,string)
end
io.open("解析结果.txt","a+"):write(table.concat(h,'\n'):gsub("[^\n%a%d%s%p]", "")):close()