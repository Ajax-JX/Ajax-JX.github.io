require 'class&'

v=Vclass("<>c__DisplayClass7_1",0x10)
gg.loadResults(v)