zz = function(Pointer, ranges)
    gg.setRanges(ranges)
    results = gg.getResults(gg.getResultsCount())
    gg.loadResults(results)
    gg.searchPointer(Pointer)
end

Vclass = function(leiming,offset)
    gg.clearResults()
    gg.setRanges(-2080892)
    gg.searchNumber(':' .. leiming, 1, false)
    local results = gg.getResults(gg.getResultsCount())
    for k, v in ipairs(results) do
        pp = string.sub(';' .. leiming, 1, 1)
        if v.value == pp then
            hqz = {{address = v.address - 1, flags = 1}}
            qb = gg.getValues(hqz)[1].value
            bl = {{address = v.address + #leiming, flags = 1}}
            bl2 = gg.getValues(bl)[1].value
            if qb == 0 and bl2 == 0 then
                jzz = {{address = v.address, flags = 1}}
                gg.loadResults(jzz)
            end
        end
    end
    zz(0, -2080892)
    local result = gg.getResults(gg.getResultsCount())
    for key, value in ipairs(result) do
        value.address = value.address - 16
    end
    gg.loadResults(result)
    zz(0, 32)
    zz(0, 32)
    local get = gg.getResults(gg.getResultsCount())
    local qop={}
    gg.clearResults()
    for abc, def in pairs(get) do
        if offset then
         qop[abc] = {address=def.value+offset,flags=def.flags}
        else
         qop[abc] = {address=def.value,flags=def.flags}
        end
    end
    return qop
end
