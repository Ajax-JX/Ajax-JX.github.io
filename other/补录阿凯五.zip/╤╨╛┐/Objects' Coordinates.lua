require 'class&'

function getName(addr)--字符数量地址
    function gv(addr,jk)
     return gg.getValues({{address=addr,flags=jk}})[1].value
    end
    l={}
    for i=0,gv(addr,4) do
       table.insert(l,string.char(gv(addr+0x4+i*0x2,1)&0xFF)) 
    end
    return table.concat(l,'')
end

u=Vclass('Body2D')
Q={}
M={}
gg.loadResults(u)
gg.searchPointer(0)
op=gg.getResults(gg.getResultsCount())
gg.clearResults()
for i,v in pairs(op) do
   if gg.getValues({{address=v.address-0x20,flags=4}})[1].value==1 then
       table.insert(M,getName(gg.getValues({{address=v.address-0x8,flags=32}})[1].value+0x10))
       table.insert(Q,{coordinate={gg.getValues({{address=v.address,flags=32}})[1].value+0x18,gg.getValues({{address=v.address,flags=32}})[1].value+0x1c},name=getName(gg.getValues({{address=v.address-0x8,flags=32}})[1].value+0x10)})
   end
end
menu=gg.choice(M,114514,'Number of objects:'..#M)
for i,v in pairs(M) do
    if i==menu then
       mu=gg.choice({'X:'..gg.getValues({{address=Q[menu]['coordinate'][1],flags=16}})[1].value,'Y:'..gg.getValues({{address=Q[menu]['coordinate'][2],flags=16}})[1].value})
       if mu==1 then
           o=gg.prompt({'输入修改数值'},{},{'number'})[1]
           gg.setValues({{address=Q[menu]['coordinate'][1],flags=16,value=o}})
       end
       if mu==2 then
           o=gg.prompt({'输入修改数值'},{},{'number'})[1]
           gg.setValues({{address=Q[menu]['coordinate'][2],flags=16,value=o}})
       end
    end
end